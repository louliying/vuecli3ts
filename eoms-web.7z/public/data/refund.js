[
	{
		"id": 1,
		"payNo": "Fgift34L7MJNFDTZV1589957737209",
		"orderPayNo": "011200528111200002",
		"businessType": "分时订单",
		"exchangeType":"支付",
		"payMethods":"微信",
		"fee": 580.00,
		"exchangeDate": "2020-05-15 18:04:34",
		"userName":"张三",
		"phone": "18312345678",
		"statusType": 1,
		"status":"已支付"
	},
	{
		"id": 11,
		"payNo": "Fgift34L7MJNFDTZV1589957737209",
		"orderPayNo": "011200528111200002",
		"businessType": "分时订单",
		"exchangeType":"支付",
		"payMethods":"微信",
		"fee": 580.00,
		"exchangeDate": "2020-05-15 18:04:34",
		"userName":"张三",
		"phone": "18312345678",
		"statusType": 1,
		"status":"已支付"
	},
	{
		"id": 12,
		"payNo": "Fgift34L7MJNFDTZV1589957737209",
		"orderPayNo": "011200528111200002",
		"businessType": "分时订单",
		"exchangeType":"支付",
		"payMethods":"微信",
		"fee": 580.00,
		"exchangeDate": "2020-05-15 18:04:34",
		"userName":"张三",
		"phone": "18312345678",
		"statusType": 1,
		"status":"已支付"
	},
	{
		"id": 2,
		"payNo": "Fgift34L7MJNFDTZV1589957737208",
		"orderPayNo":"011200528111200002",
		"businessType": "分时押金",
		"exchangeType":"支付",
		"payMethods":"支付宝",
		"fee": 580.00,
		"exchangeDate": "2020-05-15 18:04:34",
		"userName":"张三",
		"phone": "18312345678",
		"statusType": 2,
		"status":"已退款"
	},




	{
		"id": 13,
		"payNo": "Fgift34L7MJNFDTZV1589957737209",
		"orderPayNo": "011200528111200003",
		"businessType": "分时订单",
		"exchangeType":"支付",
		"payMethods":"微信",
		"fee": 580.00,
		"exchangeDate": "2020-05-15 18:04:34",
		"userName":"张三",
		"phone": "18312345678",
		"statusType": 1,
		"status":"已支付"
	},
	{
		"id": 14,
		"payNo": "Fgift34L7MJNFDTZV1589957737209",
		"orderPayNo": "011200528111200003",
		"businessType": "分时订单",
		"exchangeType":"支付",
		"payMethods":"微信",
		"fee": 580.00,
		"exchangeDate": "2020-05-15 18:04:34",
		"userName":"张三",
		"phone": "18312345678",
		"statusType": 1,
		"status":"已支付"
	},
	{
		"id": 15,
		"payNo": "Fgift34L7MJNFDTZV1589957737209",
		"orderPayNo": "011200528111200003",
		"businessType": "分时订单",
		"exchangeType":"支付",
		"payMethods":"微信",
		"fee": 580.00,
		"exchangeDate": "2020-05-15 18:04:34",
		"userName":"张三",
		"phone": "18312345678",
		"statusType": 1,
		"status":"已支付"
	}


]