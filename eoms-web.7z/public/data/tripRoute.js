{
	"invoiceInfo": {
		"userName": "赵玲玲",
		"phone": "13764466147",
		"invoiceNo": "FP2020070162842",
		"invoiceAmount": "10.00",
		"invoiceTitle":"发票抬头",
		"invoiceTitleStyle":"公司发票",
		"invoiceCompanyNO": "91370200264807TEST4A",
		"invoiceStatusName": "已处理",
		"invoiceStatus": 2,
		"companyAddress":"公司地址，公司地址",
		"companyPhone": "021-45632175",
		"bank": "开户银行",
		"bankAcount":"123456789",
		"userEmail":"user123@163.com"
	},
	"trips": [
		{
			"sendTime": "2020年7月1日 12：55",
			"sendEmail": "123@163.com",
			"operator": "admin001",
			"remark": "我是备注，我是我是备注"
		},
		{
			"sendTime": "2020年7月1日 12：55",
			"sendEmail": "12355@163.com",
			"operator": "admin001",
			"remark": "我是备注，我是我是备注aaaa"
		}
	]
}
