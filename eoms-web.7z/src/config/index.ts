let api: any = Object.create(null);
api=  {
	sPath: '',	
	login: '/api/cruiseuserbasic/w/login', //登陆
    logout: '/api/cruiseuserbasic/w/logout', //退出,

    refund: '/data/refund.js',
    triproute: '/data/tripRoute.js'

};
export default api;